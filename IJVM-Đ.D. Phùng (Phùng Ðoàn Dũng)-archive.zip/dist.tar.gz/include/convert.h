#ifndef CONVERT_H
#define CONVERT_H
#include "ijvm.h"

word_t big_bytesToInt(byte_t* bytes);
word_t little_bytesToInt(byte_t* bytes);
short Short(byte_t byte1, byte_t byte2);

#endif